import { checkForName } from "../src/client/js/nameChecker"

describe("Testing the form submit functionality", () => {
    test("Testing the checkForName() function", () => {
           expect(checkForName).toBeDefined();
})});